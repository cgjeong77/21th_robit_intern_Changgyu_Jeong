#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <vector>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_americano_btn_clicked();

    void on_latte_btn_clicked();

    void on_ade_btn_clicked();

    void on_process_btn_clicked();

    void on_clear_btn_clicked();

private:
    Ui::MainWindow *ui;
    std::vector<QString> orderQueue;
};

#endif // MAINWINDOW_H
