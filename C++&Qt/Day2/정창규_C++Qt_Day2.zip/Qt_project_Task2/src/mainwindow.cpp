#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_americano_btn_clicked()
{
    orderQueue.push_back("아메리카노");
    ui->order_list->addItem("아메리카노");
}


void MainWindow::on_latte_btn_clicked()
{
    orderQueue.push_back("카페라떼");
    ui->order_list->addItem("카페라떼");
}


void MainWindow::on_ade_btn_clicked()
{
    orderQueue.push_back("에이드");
    ui->order_list->addItem("에이드");
}


void MainWindow::on_process_btn_clicked()
{
    if (orderQueue.empty())
    {
        ui->current_order_label->setText("현재 제조 중 : 없음");
        return;
    }

    QString order = orderQueue.front();

    ui->current_order_label->setText("현재 제조 중 : " + order);

    orderQueue.erase(orderQueue.begin());

    delete ui->order_list->takeItem(0);
}


void MainWindow::on_clear_btn_clicked()
{
    orderQueue.clear();
    ui->order_list->clear();
    ui->current_order_label->setText("현재 제조 중 : 없음");
}

