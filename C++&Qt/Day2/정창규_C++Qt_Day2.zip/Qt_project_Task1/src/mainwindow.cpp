#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_forward_btn_clicked()
{
    ui->status_label->setText("현재 상태 : 전진");
}


void MainWindow::on_backward_btn_clicked()
{
    ui->status_label->setText("현재 상태 : 후진");
}


void MainWindow::on_left_btn_clicked()
{
    ui->status_label->setText("현재 상태 : 좌회전");
}


void MainWindow::on_right_btn_clicked()
{
    ui->status_label->setText("현재 상태 : 우회전");
}


void MainWindow::on_stop_btn_clicked()
{
    ui->status_label->setText("현재 상태 : 정지");
}


void MainWindow::on_speed_slider_valueChanged(int value)
{
    ui->speed_label->setText("현재 속도 : " + QString::number(value));
}

