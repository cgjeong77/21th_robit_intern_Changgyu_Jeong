#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QSizePolicy>
#include <QMessageBox>
#include <QElapsedTimer>
#include <QApplication>
#include <QThread>

#include <queue>
#include <vector>
#include <limits>
#include <utility>
#include <functional>
#include <cmath>

static void pause(int ms)
{
    QApplication::processEvents();
    QThread::msleep(ms);
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    gridLayout = new QGridLayout(ui->gridWidget);
    gridLayout->setSpacing(1);
    gridLayout->setContentsMargins(0, 0, 0, 0);

    editMode = NoneMode;
    startRow = startCol = goalRow = goalCol = -1;

    connect(ui->createMapButton, &QPushButton::clicked, this, &MainWindow::createMap);
    connect(ui->wallButton, &QPushButton::clicked, this, &MainWindow::setWallMode);
    connect(ui->startButton, &QPushButton::clicked, this, &MainWindow::setStartMode);
    connect(ui->goalButton, &QPushButton::clicked, this, &MainWindow::setGoalMode);
    connect(ui->resetButton, &QPushButton::clicked, this, &MainWindow::resetMap);
    connect(ui->dijkstraButton, &QPushButton::clicked, this, &MainWindow::runDijkstra);
    connect(ui->astarButton, &QPushButton::clicked, this, &MainWindow::runAStar);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::createMap()
{
    int rows = ui->rowSpinBox->value();
    int cols = ui->colSpinBox->value();

    while (QLayoutItem *item = gridLayout->takeAt(0)) {
        if (item->widget()) delete item->widget();
        delete item;
    }

    cells.assign(rows, std::vector<QPushButton*>(cols));
    cellTypes.assign(rows, std::vector<CellType>(cols, Empty));

    startRow = startCol = goalRow = goalCol = -1;
    editMode = NoneMode;
    clearResults();

    for (int row = 0; row < rows; row++) {
        for (int col = 0; col < cols; col++) {
            QPushButton *button = new QPushButton(ui->gridWidget);
            button->setText("");
            button->setMinimumSize(20, 20);
            button->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

            gridLayout->addWidget(button, row, col);
            cells[row][col] = button;
            updateCellStyle(row, col);

            connect(button, &QPushButton::clicked, this, [this, row, col]() {
                handleCellClick(row, col);
            });
        }

        gridLayout->setRowStretch(row, 1);
    }

    for (int col = 0; col < cols; col++)
        gridLayout->setColumnStretch(col, 1);
}

void MainWindow::setWallMode()
{
    editMode = WallMode;
}

void MainWindow::setStartMode()
{
    editMode = StartMode;
}

void MainWindow::setGoalMode()
{
    editMode = GoalMode;
}

void MainWindow::handleCellClick(int row, int col)
{
    clearSearchVisualization();
    clearResults();

    if (editMode == WallMode) {
        if (cellTypes[row][col] == Start || cellTypes[row][col] == Goal) return;
        cellTypes[row][col] = cellTypes[row][col] == Empty ? Wall : Empty;
    }
    else if (editMode == StartMode) {
        if (cellTypes[row][col] == Wall || cellTypes[row][col] == Goal) return;

        if (startRow != -1) {
            cellTypes[startRow][startCol] = Empty;
            updateCellStyle(startRow, startCol);
        }

        startRow = row;
        startCol = col;
        cellTypes[row][col] = Start;
    }
    else if (editMode == GoalMode) {
        if (cellTypes[row][col] == Wall || cellTypes[row][col] == Start) return;

        if (goalRow != -1) {
            cellTypes[goalRow][goalCol] = Empty;
            updateCellStyle(goalRow, goalCol);
        }

        goalRow = row;
        goalCol = col;
        cellTypes[row][col] = Goal;
    }

    updateCellStyle(row, col);
}

void MainWindow::updateCellStyle(int row, int col)
{
    QString color = "white";

    if (cellTypes[row][col] == Wall) color = "black";
    else if (cellTypes[row][col] == Start) color = "green";
    else if (cellTypes[row][col] == Goal) color = "red";

    cells[row][col]->setStyleSheet(
        "background-color: " + color + "; border: 1px solid gray;"
        );
}

void MainWindow::resetMap()
{
    if (cells.empty()) return;

    for (int row = 0; row < (int)cells.size(); row++) {
        for (int col = 0; col < (int)cells[row].size(); col++) {
            cellTypes[row][col] = Empty;
            updateCellStyle(row, col);
        }
    }

    startRow = startCol = goalRow = goalCol = -1;
    editMode = NoneMode;
    clearResults();
}

void MainWindow::clearResults()
{
    ui->costLabel->setText("-");
    ui->visitedLabel->setText("-");
    ui->timeLabel->setText("-");
}

void MainWindow::clearSearchVisualization()
{
    for (int row = 0; row < (int)cells.size(); row++)
        for (int col = 0; col < (int)cells[row].size(); col++)
            updateCellStyle(row, col);
}

bool MainWindow::checkSearchReady()
{
    if (cells.empty()) {
        QMessageBox::warning(this, "경고", "먼저 맵을 생성해주세요.");
        return false;
    }

    if (startRow == -1) {
        QMessageBox::warning(this, "경고", "시작점을 설정해주세요.");
        return false;
    }

    if (goalRow == -1) {
        QMessageBox::warning(this, "경고", "도착점을 설정해주세요.");
        return false;
    }

    return true;
}

void MainWindow::runDijkstra()
{
    if (!checkSearchReady()) return;

    clearSearchVisualization();
    clearResults();

    int rows = cells.size();
    int cols = cells[0].size();
    const int INF = std::numeric_limits<int>::max();

    std::vector<std::vector<int>> dist(rows, std::vector<int>(cols, INF));
    std::vector<std::vector<bool>> visited(rows, std::vector<bool>(cols, false));
    std::vector<std::vector<std::pair<int, int>>> parent(
        rows, std::vector<std::pair<int, int>>(cols, {-1, -1})
        );

    std::vector<std::pair<int, int>> searchOrder;

    using Node = std::pair<int, std::pair<int, int>>;
    std::priority_queue<Node, std::vector<Node>, std::greater<Node>> pq;

    dist[startRow][startCol] = 0;
    pq.push({0, {startRow, startCol}});

    int dr[4] = {-1, 1, 0, 0};
    int dc[4] = {0, 0, -1, 1};
    int visitedCount = 0;

    QElapsedTimer timer;
    timer.start();

    while (!pq.empty()) {
        Node current = pq.top();
        pq.pop();

        int cost = current.first;
        int row = current.second.first;
        int col = current.second.second;

        if (visited[row][col]) continue;

        visited[row][col] = true;
        visitedCount++;
        searchOrder.push_back({row, col});

        if (row == goalRow && col == goalCol) break;

        for (int i = 0; i < 4; i++) {
            int nr = row + dr[i];
            int nc = col + dc[i];

            if (nr < 0 || nr >= rows || nc < 0 || nc >= cols) continue;
            if (cellTypes[nr][nc] == Wall) continue;

            int newCost = cost + 1;

            if (newCost < dist[nr][nc]) {
                dist[nr][nc] = newCost;
                parent[nr][nc] = {row, col};
                pq.push({newCost, {nr, nc}});
            }
        }
    }

    double elapsedMs = timer.nsecsElapsed() / 1000000.0;

    for (auto pos : searchOrder) {
        int row = pos.first;
        int col = pos.second;

        if (cellTypes[row][col] != Start && cellTypes[row][col] != Goal) {
            cells[row][col]->setStyleSheet(
                "background-color: lightblue; border: 1px solid gray;"
                );
            pause(30);
        }
    }

    if (dist[goalRow][goalCol] == INF) {
        ui->costLabel->setText("경로 없음");
        ui->visitedLabel->setText(QString::number(visitedCount));
        ui->timeLabel->setText(QString::number(elapsedMs, 'f', 3) + " ms");
        QMessageBox::information(this, "탐색 결과", "경로가 없습니다.");
        return;
    }

    int row = goalRow;
    int col = goalCol;

    while (!(row == startRow && col == startCol)) {
        if (cellTypes[row][col] != Goal) {
            cells[row][col]->setStyleSheet(
                "background-color: yellow; border: 1px solid gray;"
                );
            pause(40);
        }

        auto previous = parent[row][col];
        row = previous.first;
        col = previous.second;
    }

    updateCellStyle(startRow, startCol);
    updateCellStyle(goalRow, goalCol);

    ui->costLabel->setText(QString::number(dist[goalRow][goalCol]));
    ui->visitedLabel->setText(QString::number(visitedCount));
    ui->timeLabel->setText(QString::number(elapsedMs, 'f', 3) + " ms");
}

int MainWindow::heuristic(int row, int col)
{
    return std::abs(row - goalRow) + std::abs(col - goalCol);
}

void MainWindow::runAStar()
{
    if (!checkSearchReady()) return;

    clearSearchVisualization();
    clearResults();

    int rows = cells.size();
    int cols = cells[0].size();
    const int INF = std::numeric_limits<int>::max();

    std::vector<std::vector<int>> gCost(rows, std::vector<int>(cols, INF));
    std::vector<std::vector<bool>> visited(rows, std::vector<bool>(cols, false));
    std::vector<std::vector<std::pair<int, int>>> parent(
        rows, std::vector<std::pair<int, int>>(cols, {-1, -1})
        );

    std::vector<std::pair<int, int>> searchOrder;

    using Node = std::pair<int, std::pair<int, int>>;
    std::priority_queue<Node, std::vector<Node>, std::greater<Node>> openList;

    gCost[startRow][startCol] = 0;
    openList.push({heuristic(startRow, startCol), {startRow, startCol}});

    int dr[4] = {-1, 1, 0, 0};
    int dc[4] = {0, 0, -1, 1};
    int visitedCount = 0;

    QElapsedTimer timer;
    timer.start();

    while (!openList.empty()) {
        Node current = openList.top();
        openList.pop();

        int row = current.second.first;
        int col = current.second.second;

        if (visited[row][col]) continue;

        visited[row][col] = true;
        visitedCount++;
        searchOrder.push_back({row, col});

        if (row == goalRow && col == goalCol) break;

        for (int i = 0; i < 4; i++) {
            int nr = row + dr[i];
            int nc = col + dc[i];

            if (nr < 0 || nr >= rows || nc < 0 || nc >= cols) continue;
            if (cellTypes[nr][nc] == Wall) continue;

            int newG = gCost[row][col] + 1;

            if (newG < gCost[nr][nc]) {
                gCost[nr][nc] = newG;
                parent[nr][nc] = {row, col};

                int f = newG + heuristic(nr, nc);
                openList.push({f, {nr, nc}});
            }
        }
    }

    double elapsedMs = timer.nsecsElapsed() / 1000000.0;

    for (auto pos : searchOrder) {
        int row = pos.first;
        int col = pos.second;

        if (cellTypes[row][col] != Start && cellTypes[row][col] != Goal) {
            cells[row][col]->setStyleSheet(
                "background-color: lightblue; border: 1px solid gray;"
                );
            pause(30);
        }
    }

    if (gCost[goalRow][goalCol] == INF) {
        ui->costLabel->setText("경로 없음");
        ui->visitedLabel->setText(QString::number(visitedCount));
        ui->timeLabel->setText(QString::number(elapsedMs, 'f', 3) + " ms");
        QMessageBox::information(this, "탐색 결과", "경로가 없습니다.");
        return;
    }

    int row = goalRow;
    int col = goalCol;

    while (!(row == startRow && col == startCol)) {
        if (cellTypes[row][col] != Goal) {
            cells[row][col]->setStyleSheet(
                "background-color: yellow; border: 1px solid gray;"
                );
            pause(40);
        }

        auto previous = parent[row][col];
        row = previous.first;
        col = previous.second;
    }

    updateCellStyle(startRow, startCol);
    updateCellStyle(goalRow, goalCol);

    ui->costLabel->setText(QString::number(gCost[goalRow][goalCol]));
    ui->visitedLabel->setText(QString::number(visitedCount));
    ui->timeLabel->setText(QString::number(elapsedMs, 'f', 3) + " ms");
}
