#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QGridLayout>
#include <vector>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void createMap();
    void setWallMode();
    void setStartMode();
    void setGoalMode();
    void resetMap();
    void runDijkstra();
    void runAStar();

private:
    Ui::MainWindow *ui;
    QGridLayout *gridLayout;
    std::vector<std::vector<QPushButton*>> cells;

    enum CellType { Empty, Wall, Start, Goal };
    enum EditMode { NoneMode, WallMode, StartMode, GoalMode };

    std::vector<std::vector<CellType>> cellTypes;
    EditMode editMode;

    int startRow, startCol;
    int goalRow, goalCol;

    void handleCellClick(int row, int col);
    void updateCellStyle(int row, int col);
    void clearResults();
    void clearSearchVisualization();
    bool checkSearchReady();
    int heuristic(int row, int col);
};

#endif
